import os
import json

# Stock Screening Criteria
LTP_MIN = 30.0
LTP_MAX = 500.0

# Liquidity Filter (Default threshold: 10 Lakhs = 1,000,000 as per assignment spec)
BID_QTY_MIN = 1_000_000
ASK_QTY_MIN = 1_000_000

# Moving Average Parameters
SMMA_FAST_PERIOD = 20
SMMA_SLOW_PERIOD = 120

# Sliding Window Aggregation Periods (in seconds)
WINDOW_5M = 5 * 60
WINDOW_20M = 20 * 60
WINDOW_60M = 60 * 60

# Default Path for Safe Credentials
CONFIG_DIR = os.path.dirname(os.path.abspath(__file__))
CREDENTIALS_FILE = os.path.join(CONFIG_DIR, "credentials.json")
MOCK_CREDENTIALS_FILE = os.path.join(CONFIG_DIR, "credentials.example.json")

def load_credentials():
    """Load credentials from credentials.json safely."""
    if os.path.exists(CREDENTIALS_FILE):
        with open(CREDENTIALS_FILE, 'r') as f:
            return json.load(f)
    return {
        "broker": "ANGEL_ONE",
        "api_key": "YOUR_ANGEL_ONE_API_KEY",
        "client_code": "YOUR_CLIENT_CODE",
        "password": "YOUR_PASSWORD",
        "totp_key": "YOUR_TOTP_KEY",
        "use_simulator": True  # Defaults to True for safe off-market testing
    }

def get_masked_credentials(creds):
    """Mask sensitive fields for logs, assignment submission & UI display."""
    masked = creds.copy()
    for key in ["api_key", "client_code", "password", "totp_key"]:
        if key in masked and masked[key]:
            val = str(masked[key])
            if len(val) > 4:
                masked[key] = val[:2] + "*****" + val[-2:]
            else:
                masked[key] = "*****"
    return masked
