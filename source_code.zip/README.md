# 🚀 Stock Market AI/ML Screening & Analysis System - Submission Guide

Welcome! This repository contains the complete solution for **Assignment 1 – AI/ML-Based Stock Market Screening and Analysis System**.

---

## 📌 Features Implemented

1. **Real-Time Stock Screener**:
   - Filtered for **LTP between ₹30 and ₹500**.
   - Liquidity Filter: **Bid Quantity > 10,00,000 & Ask Quantity > 10,00,000**.
2. **Quantitative Technical Indicators**:
   - **SMMA(20)** & **SMMA(120)** calculated live on streaming ticks.
   - **Exchange Traded Quantity**: Last 5 minutes, 20 minutes, 60 minutes.
   - **Average LTP**: Last 20 minutes and 60 minutes.
   - **Market Depth**: Live Top Bid/Ask prices & total depth volume.
3. **AI/ML Signal Validation & Explainability (XAI)**:
   - Evaluates SMMA (20/120) **BUY** (20 crosses above 120) and **SELL** (20 crosses below 120) crossovers.
   - Computes **Win Probability (%)** using order book imbalance ratios, volume surge indices, and price volatility.
   - Explains reasons for accepting or avoiding trades in plain language.
4. **Broker Integration & Live Simulator**:
   - Angel One SmartAPI connection ready.
   - Built-in **Live Market Simulator** to test/record off-market 24/7.
5. **Standalone Executable (.exe)**:
   - Built with PyInstaller with masked credential security.

---

## 🛠 How to Run & Test

### Option A: Running from Python
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Run the application:
   ```bash
   python main.py
   ```

### Option B: Building the Standalone `.exe`
Run the automated build script:
```bash
python build_exe.py
```
The resulting `StockMarket_AIML_Screener.exe` will be saved in the `dist/` directory.

---

## 🔐 Credentials & API Key Security
Per submission guidelines, all API keys in `config/credentials.json` are automatically masked to `***HIDDEN***` when displayed in logs or on screen.

---

## 🎥 Screen Recording Script (for your assignment submission video)

When recording your screen demonstration, cover these 4 key sections:

1. **Introduction & Launch (0:00 - 0:30)**:
   - Show the project directory and open `StockMarket_AIML_Screener.exe` or run `python main.py`.
   - Highlight the dark mode CustomTkinter quantitative UI layout.

2. **Live Stock Screening & Liquidity Filter (0:30 - 1:15)**:
   - Point out that stocks are filtered where LTP is between ₹30 and ₹500.
   - Show that stocks like `YESBANK` (< ₹30) or `RELIANCE` (> ₹500) are automatically excluded.
   - Show live Bid Quantity & Ask Quantity maintaining > 10 Lakh liquidity.

3. **Live Indicator & Volume Sliding Windows (1:15 - 2:00)**:
   - Highlight SMMA (20) and SMMA (120) columns updating live.
   - Point out the 5m, 20m, 60m Traded Volume and 20m, 60m Average LTP windows.

4. **AI/ML Crossover Analysis & Explainable AI (2:00 - 3:00)**:
   - Click on any stock row (e.g. `TATASTEEL` or `ZOMATO`).
   - Show the bottom **AI/ML Signal Validation & Explainability Engine** box.
   - Explain how the AI evaluates win probability and outputs natural language trade rejection reasons (e.g. *"Avoided: Low volume expansion during bullish crossover"*).
