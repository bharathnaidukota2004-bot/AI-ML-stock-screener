import sys
import os

# Ensure local imports resolve cleanly
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ui.main_window import StockScreenerApp

def main():
    print("========================================================================")
    print("STARTING: AI/ML Stock Market Screening & Quantitative Analysis System")
    print("========================================================================")
    app = StockScreenerApp()
    app.mainloop()

if __name__ == "__main__":
    main()
