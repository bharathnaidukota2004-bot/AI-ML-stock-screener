import customtkinter as ctk
import tkinter as tk
from tkinter import ttk
import threading
import time
from config.settings import load_credentials, get_masked_credentials, LTP_MIN, LTP_MAX, BID_QTY_MIN, ASK_QTY_MIN
from core.broker_streamer import BrokerStreamer
from ml.crossover_evaluator import AICrossoverEvaluator

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

class StockScreenerApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("AI/ML Stock Market Screening & Quantitative Analysis System")
        self.geometry("1380x860")

        self.credentials = load_credentials()
        self.ai_evaluator = AICrossoverEvaluator()
        self.latest_data = {}
        self.crossover_states = {} # Tracks previous SMMA(20) vs SMMA(120) relation

        self._build_header()
        self._build_filter_bar()
        self._build_screener_table()
        self._build_ai_analysis_panel()
        self._build_statusbar()

        # Start Market Feed Streamer
        self.streamer = BrokerStreamer(self.credentials, self.on_tick_update)
        self.streamer.start()

        # UI Auto-refresh timer
        self.after(500, self._periodic_ui_refresh)

    def _build_header(self):
        header_frame = ctk.CTkFrame(self, fg_color="#1E1E2E", corner_radius=8)
        header_frame.pack(fill="x", padx=15, pady=(15, 5))

        title_lbl = ctk.CTkLabel(
            header_frame, 
            text="AI/ML Real-Time Stock Screener & Quantitative Analysis", 
            font=ctk.CTkFont(size=20, weight="bold"),
            text_color="#F5E0DC"
        )
        title_lbl.pack(side="left", padx=15, pady=12)

        masked_creds = get_masked_credentials(self.credentials)
        cred_text = f"Broker: {masked_creds['broker']} | Client: {masked_creds['client_code']} | Mode: {'LIVE SIMULATOR' if self.credentials.get('use_simulator') else 'ANGEL ONE LIVE'}"
        
        mode_lbl = ctk.CTkLabel(
            header_frame,
            text=cred_text,
            font=ctk.CTkFont(size=12),
            text_color="#A6ADC8"
        )
        mode_lbl.pack(side="right", padx=15, pady=12)

    def _build_filter_bar(self):
        filter_frame = ctk.CTkFrame(self, fg_color="#181825", corner_radius=8)
        filter_frame.pack(fill="x", padx=15, pady=5)

        lbl = ctk.CTkLabel(
            filter_frame,
            text="🎯 Active Screening Filters:  LTP: ₹30 – ₹500  |  Min Liquidity: Bid Qty > 10,00,000 & Ask Qty > 10,00,000  |  Indicators: SMMA(20) & SMMA(120)",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color="#89B4FA"
        )
        lbl.pack(padx=15, pady=8, side="left")

    def _build_screener_table(self):
        table_container = ctk.CTkFrame(self, fg_color="#1E1E2E", corner_radius=8)
        table_container.pack(fill="both", expand=True, padx=15, pady=5)

        # Style Treeview
        style = ttk.Style()
        style.theme_use("default")
        style.configure("Treeview", 
                        background="#181825",
                        foreground="#CDD6F4",
                        rowheight=32,
                        fieldbackground="#181825",
                        font=("Segoe UI", 10))
        style.configure("Treeview.Heading", 
                        background="#313244", 
                        foreground="#F5E0DC", 
                        font=("Segoe UI", 10, "bold"))
        style.map("Treeview", background=[("selected", "#45475A")])

        columns = (
            "symbol", "ltp", "bid_price", "bid_depth", "ask_price", "ask_depth", 
            "smma_20", "smma_120", "vol_5m", "vol_20m", "vol_60m", 
            "avg_p_20m", "avg_p_60m", "crossover"
        )

        self.tree = ttk.Treeview(table_container, columns=columns, show="headings", selectmode="browse")
        
        headers = {
            "symbol": "Symbol",
            "ltp": "LTP (₹)",
            "bid_price": "Bid Price (₹)",
            "bid_depth": "Bid Qty (Live)",
            "ask_price": "Ask Price (₹)",
            "ask_depth": "Ask Qty (Live)",
            "smma_20": "SMMA (20)",
            "smma_120": "SMMA (120)",
            "vol_5m": "Vol (5m)",
            "vol_20m": "Vol (20m)",
            "vol_60m": "Vol (60m)",
            "avg_p_20m": "Avg P (20m)",
            "avg_p_60m": "Avg P (60m)",
            "crossover": "SMMA Crossover Status"
        }

        for col, text in headers.items():
            self.tree.heading(col, text=text)
            self.tree.column(col, anchor="center", width=100)

        self.tree.column("symbol", width=120)
        self.tree.column("crossover", width=180)

        # Scrollbar
        sb = ttk.Scrollbar(table_container, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        
        self.tree.pack(side="left", fill="both", expand=True, padx=5, pady=5)
        sb.pack(side="right", fill="y", pady=5)

        self.tree.bind("<<TreeviewSelect>>", self._on_row_select)

    def _build_ai_analysis_panel(self):
        panel = ctk.CTkFrame(self, fg_color="#181825", corner_radius=8, height=200)
        panel.pack(fill="x", padx=15, pady=(5, 15))

        title = ctk.CTkLabel(
            panel, 
            text="🧠 AI/ML Signal Validation, Explainability (XAI) & Dynamic Depth Visualizer", 
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color="#A6E3A1"
        )
        title.pack(anchor="w", padx=15, pady=(8, 4))

        content_box = ctk.CTkFrame(panel, fg_color="transparent")
        content_box.pack(fill="both", expand=True, padx=15, pady=(0, 8))

        # Left Text Output
        self.ai_output_box = ctk.CTkTextbox(
            content_box, 
            height=130, 
            fg_color="#11111B", 
            text_color="#F5E0DC", 
            font=ctk.CTkFont(family="Consolas", size=11),
            wrap="word"
        )
        self.ai_output_box.pack(side="left", fill="both", expand=True, padx=(0, 10))
        self.ai_output_box.insert("1.0", "Select a stock row or await live SMMA (20/120) crossovers for real-time AI signal evaluation and graphical market depth visualizer...")
        self.ai_output_box.configure(state="disabled")

        # Right Graphical Market Depth Visualizer Canvas
        chart_frame = ctk.CTkFrame(content_box, fg_color="#11111B", corner_radius=6, width=320)
        chart_frame.pack(side="right", fill="y")
        chart_frame.pack_propagate(False)

        chart_lbl = ctk.CTkLabel(chart_frame, text="📊 Live Order Book Imbalance", font=ctk.CTkFont(size=11, weight="bold"), text_color="#89B4FA")
        chart_lbl.pack(pady=(4, 2))

        self.canvas = tk.Canvas(chart_frame, bg="#11111B", highlightthickness=0, height=95, width=300)
        self.canvas.pack(padx=10, pady=2)
        self._draw_placeholder_chart()

    def _draw_placeholder_chart(self):
        self.canvas.delete("all")
        self.canvas.create_text(150, 45, text="Select stock row\nto view Order Book chart", fill="#6C7086", font=("Segoe UI", 10), justify="center")

    def _build_statusbar(self):
        self.status_bar = ctk.CTkLabel(
            self, 
            text="System Ready | Live Market Feed Connected", 
            anchor="w", 
            font=ctk.CTkFont(size=11),
            text_color="#A6ADC8"
        )
        self.status_bar.pack(fill="x", padx=15, pady=(0, 5))

    def on_tick_update(self, symbol, data, metrics):
        """Callback received on every tick."""
        self.latest_data[symbol] = {
            'data': data,
            'metrics': metrics,
            'ts': time.time()
        }

    def _periodic_ui_refresh(self):
        """Refreshes table and checks for SMMA Crossovers."""
        for symbol, entry in list(self.latest_data.items()):
            data = entry['data']
            metrics = entry['metrics']
            ltp = data['ltp']
            bid_qty = data['total_bid_qty']
            ask_qty = data['total_ask_qty']

            # 1. Stock Screening Criteria: ₹30 <= LTP <= ₹500
            if not (LTP_MIN <= ltp <= LTP_MAX):
                if self.tree.exists(symbol):
                    self.tree.delete(symbol)
                continue

            # 2. Liquidity Filter Criteria: Bid Qty > 10,00,000 & Ask Qty > 10,00,000
            if not (bid_qty >= BID_QTY_MIN and ask_qty >= ASK_QTY_MIN):
                if self.tree.exists(symbol):
                    self.tree.delete(symbol)
                continue

            # 3. Detect SMMA (20/120) Crossover
            smma_20 = metrics['smma_20']
            smma_120 = metrics['smma_120']
            prev_rel = self.crossover_states.get(symbol, "NEUTRAL")

            crossover_text = "NEUTRAL"
            if smma_20 > smma_120:
                crossover_text = "BULLISH (20 > 120)"
                current_rel = "ABOVE"
            elif smma_20 < smma_120:
                crossover_text = "BEARISH (20 < 120)"
                current_rel = "BELOW"
            else:
                current_rel = prev_rel

            # Trigger AI evaluation on crossover event
            if prev_rel != "NEUTRAL" and current_rel != prev_rel:
                sig_type = "BUY" if current_rel == "ABOVE" else "SELL"
                eval_res = self.ai_evaluator.evaluate_signal(sig_type, symbol, data, metrics)
                self._display_ai_result(symbol, eval_res)

            self.crossover_states[symbol] = current_rel

            bid_price = data.get('best_bid_price', ltp)
            ask_price = data.get('best_ask_price', ltp)

            row_values = (
                symbol,
                f"₹{ltp:.2f}",
                f"₹{bid_price:.2f}",
                f"{bid_qty:,}",
                f"₹{ask_price:.2f}",
                f"{ask_qty:,}",
                f"{smma_20:.2f}",
                f"{smma_120:.2f}",
                f"{metrics['vol_5m']:,}",
                f"{metrics['vol_20m']:,}",
                f"{metrics['vol_60m']:,}",
                f"₹{metrics['avg_price_20m']:.2f}",
                f"₹{metrics['avg_price_60m']:.2f}",
                crossover_text
            )

            if self.tree.exists(symbol):
                self.tree.item(symbol, values=row_values)
            else:
                self.tree.insert("", "end", iid=symbol, values=row_values)

        self.after(500, self._periodic_ui_refresh)

    def _on_row_select(self, event):
        selected = self.tree.selection()
        if not selected:
            return
        symbol = selected[0]
        if symbol in self.latest_data:
            entry = self.latest_data[symbol]
            metrics = entry['metrics']
            data = entry['data']
            smma_20 = metrics['smma_20']
            smma_120 = metrics['smma_120']
            sig_type = "BUY" if smma_20 >= smma_120 else "SELL"
            
            eval_res = self.ai_evaluator.evaluate_signal(sig_type, symbol, data, metrics)
            self._display_ai_result(symbol, eval_res)

    def _display_ai_result(self, symbol, eval_res):
        self.ai_output_box.configure(state="normal")
        self.ai_output_box.delete("1.0", "end")
        
        status_tag = "✅ APPROVED" if eval_res['is_approved'] else "⚠️ AVOID / REJECTED"
        text = f"[{time.strftime('%H:%M:%S')}] STOCK: {symbol} | SIGNAL: {eval_res['signal_type']} CROSSOVER | STATUS: {status_tag}\n"
        text += f"WIN PROBABILITY: {eval_res['probability']}%\n"
        text += f"ANALYSIS & EXPLANATION: {eval_res['explanation']}\n"
        text += f"QUANT METRICS: Depth Imbalance: {eval_res['features']['depth_imbalance']:.2f} | Vol Surge Ratio: {eval_res['features']['vol_surge_ratio']:.2f}x | SMMA Spread: {eval_res['features']['smma_spread']*100:.2f}%"

        self.ai_output_box.insert("1.0", text)
        self.ai_output_box.configure(state="disabled")

        # Draw Live Graphical Order Book Depth Bar Chart on Canvas
        self._draw_depth_chart(symbol, eval_res)

    def _draw_depth_chart(self, symbol, eval_res):
        self.canvas.delete("all")
        imbalance = eval_res['features']['depth_imbalance'] # -1.0 to +1.0
        prob = eval_res['probability']
        
        # Draw Stock symbol title
        self.canvas.create_text(150, 12, text=f"Order Book: {symbol}", fill="#CDD6F4", font=("Segoe UI", 10, "bold"))
        
        # Calculate bar widths (Bid Qty vs Ask Qty ratio)
        # Normalized between 10px and 260px width
        bid_pct = max(0.1, min(0.9, (imbalance + 1.0) / 2.0))
        ask_pct = 1.0 - bid_pct

        # Bid Depth Bar (Green)
        bid_w = int(260 * bid_pct)
        self.canvas.create_rectangle(20, 26, 20 + bid_w, 42, fill="#A6E3A1", outline="")
        self.canvas.create_text(25, 34, text=f"Bids: {int(bid_pct*100)}%", fill="#11111B", font=("Segoe UI", 9, "bold"), anchor="w")

        # Ask Depth Bar (Red)
        ask_w = 260 - bid_w
        self.canvas.create_rectangle(20 + bid_w, 26, 280, 42, fill="#F38BA8", outline="")
        self.canvas.create_text(275, 34, text=f"Asks: {int(ask_pct*100)}%", fill="#11111B", font=("Segoe UI", 9, "bold"), anchor="e")

        # Probability Gauge Bar below
        prob_color = "#A6E3A1" if prob >= 60 else "#F38BA8"
        self.canvas.create_text(150, 56, text=f"AI Win Probability Score: {prob}%", fill=prob_color, font=("Segoe UI", 9, "bold"))
        
        # Probability Bar track
        self.canvas.create_rectangle(20, 68, 280, 78, fill="#313244", outline="")
        prob_w = int(260 * (prob / 100.0))
        self.canvas.create_rectangle(20, 68, 20 + prob_w, 78, fill=prob_color, outline="")

if __name__ == "__main__":
    app = StockScreenerApp()
    app.mainloop()
