import customtkinter as ctk
import tkinter as tk
from tkinter import ttk
import threading
import time
from config.settings import load_credentials, get_masked_credentials, LTP_MIN, LTP_MAX, BID_QTY_MIN, ASK_QTY_MIN
from core.broker_streamer import BrokerStreamer
from core.paper_trader import PaperTrader
from ml.crossover_evaluator import AICrossoverEvaluator

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

class StockScreenerApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("AI/ML 1-Min Stock Screener, Day 1 Model Training & Live Paper Trading Engine")
        self.geometry("1420x900")

        self.credentials = load_credentials()
        self.ai_evaluator = AICrossoverEvaluator()
        self.paper_trader = PaperTrader()
        
        self.latest_data = {}
        self.crossover_states = {} # Tracks previous SMMA(20) vs SMMA(120) relation

        self._build_header()
        self._build_tabview()
        self._build_statusbar()

        # Train initial Day 1 ML Model in background thread
        threading.Thread(target=self._auto_train_ml_model, daemon=True).start()

        # Start Market Feed Streamer
        self.streamer = BrokerStreamer(self.credentials, self.on_tick_update)
        self.streamer.start()

        # UI Auto-refresh timer
        self.after(500, self._periodic_ui_refresh)

    def _auto_train_ml_model(self):
        summary = self.ai_evaluator.train_model()
        self._pending_ml_summary = summary

    def _build_header(self):
        header_frame = ctk.CTkFrame(self, fg_color="#1E1E2E", corner_radius=8)
        header_frame.pack(fill="x", padx=15, pady=(12, 4))

        title_lbl = ctk.CTkLabel(
            header_frame, 
            text="📈 AI/ML Stock Market Quantitative Screener & Paper Trading Engine", 
            font=ctk.CTkFont(size=18, weight="bold"),
            text_color="#F5E0DC"
        )
        title_lbl.pack(side="left", padx=15, pady=10)

        masked_creds = get_masked_credentials(self.credentials)
        cred_text = f"Timeframe: 1-Min | SMMA: (20/120) | Mode: REAL-TIME FEED | Broker: {masked_creds['broker']}"
        
        mode_lbl = ctk.CTkLabel(
            header_frame,
            text=cred_text,
            font=ctk.CTkFont(size=11),
            text_color="#A6ADC8"
        )
        mode_lbl.pack(side="right", padx=15, pady=10)

    def _build_tabview(self):
        self.tabview = ctk.CTkTabview(self, fg_color="#181825", segmented_button_selected_color="#89B4FA")
        self.tabview.pack(fill="both", expand=True, padx=15, pady=5)

        self.tab_screener = self.tabview.add("📈 Live 1-Min Screener")
        self.tab_training = self.tabview.add("🤖 Day 1 ML Training & Features")
        self.tab_papertrade = self.tabview.add("📊 Live Paper Trading & Win/Loss Stats")

        self._build_screener_tab()
        self._build_training_tab()
        self._build_papertrade_tab()

    def _build_screener_tab(self):
        filter_bar = ctk.CTkFrame(self.tab_screener, fg_color="#11111B", corner_radius=6)
        filter_bar.pack(fill="x", padx=10, pady=5)

        lbl = ctk.CTkLabel(
            filter_bar,
            text="🎯 1-Min Criteria: LTP ₹30–₹500 | Liquidity > 10L | Short: 20 SMMA | Long: 120 SMMA | Feature: LTQ Volume Expansion",
            font=ctk.CTkFont(size=11, weight="bold"),
            text_color="#89B4FA"
        )
        lbl.pack(padx=10, pady=6, side="left")

        table_container = ctk.CTkFrame(self.tab_screener, fg_color="#1E1E2E", corner_radius=6)
        table_container.pack(fill="both", expand=True, padx=10, pady=5)

        style = ttk.Style()
        style.theme_use("default")
        style.configure("Treeview", background="#181825", foreground="#CDD6F4", rowheight=30, fieldbackground="#181825", font=("Segoe UI", 10))
        style.configure("Treeview.Heading", background="#313244", foreground="#F5E0DC", font=("Segoe UI", 10, "bold"))
        style.map("Treeview", background=[("selected", "#45475A")])

        columns = ("symbol", "ltp", "bid_price", "bid_depth", "ask_price", "ask_depth", "smma_20", "smma_120", "vol_5m", "ltq_ratio", "crossover")
        self.tree = ttk.Treeview(table_container, columns=columns, show="headings", selectmode="browse")
        
        headers = {
            "symbol": "Symbol", "ltp": "LTP (₹)", "bid_price": "Bid Price", "bid_depth": "Bid Qty (10L+)",
            "ask_price": "Ask Price", "ask_depth": "Ask Qty (10L+)", "smma_20": "20 SMMA", "smma_120": "120 SMMA",
            "vol_5m": "Vol (5m)", "ltq_ratio": "LTQ Ratio", "crossover": "20/120 SMMA Crossover"
        }
        for col, text in headers.items():
            self.tree.heading(col, text=text)
            self.tree.column(col, anchor="center", width=100)

        self.tree.column("symbol", width=110)
        self.tree.column("crossover", width=170)

        sb = ttk.Scrollbar(table_container, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side="left", fill="both", expand=True, padx=5, pady=5)
        sb.pack(side="right", fill="y", pady=5)
        self.tree.bind("<<TreeviewSelect>>", self._on_row_select)

        # AI Analysis Panel
        panel = ctk.CTkFrame(self.tab_screener, fg_color="#11111B", corner_radius=6, height=160)
        panel.pack(fill="x", padx=10, pady=(5, 10))

        content_box = ctk.CTkFrame(panel, fg_color="transparent")
        content_box.pack(fill="both", expand=True, padx=10, pady=6)

        self.ai_output_box = ctk.CTkTextbox(content_box, height=130, fg_color="#181825", text_color="#F5E0DC", font=ctk.CTkFont(family="Consolas", size=10), wrap="word")
        self.ai_output_box.pack(side="left", fill="both", expand=True, padx=(0, 10))
        self.ai_output_box.insert("1.0", "Awaiting live 20/120 SMMA crossovers for Day 1 ML model signal verification and avoidance explanation...")
        self.ai_output_box.configure(state="disabled")

        chart_frame = ctk.CTkFrame(content_box, fg_color="#181825", corner_radius=6, width=300)
        chart_frame.pack(side="right", fill="y")
        chart_frame.pack_propagate(False)

        chart_lbl = ctk.CTkLabel(chart_frame, text="📊 Live Order Book Imbalance", font=ctk.CTkFont(size=10, weight="bold"), text_color="#89B4FA")
        chart_lbl.pack(pady=(4, 2))

        self.canvas = tk.Canvas(chart_frame, bg="#181825", highlightthickness=0, height=95, width=280)
        self.canvas.pack(padx=10, pady=2)
        self._draw_placeholder_chart()

    def _draw_placeholder_chart(self):
        self.canvas.delete("all")
        self.canvas.create_text(140, 45, text="Select stock row\nto view Order Book depth", fill="#6C7086", font=("Segoe UI", 9), justify="center")

    def _build_training_tab(self):
        ctrl_frame = ctk.CTkFrame(self.tab_training, fg_color="#11111B", corner_radius=6)
        ctrl_frame.pack(fill="x", padx=10, pady=10)

        lbl = ctk.CTkLabel(ctrl_frame, text="🤖 Day 1 ML Model Training Pipeline (1-Min Crossovers & Feature Permutations)", font=ctk.CTkFont(size=12, weight="bold"), text_color="#A6E3A1")
        lbl.pack(side="left", padx=15, pady=10)

        btn_train = ctk.CTkButton(ctrl_frame, text="⚡ Retrain Day 1 ML Model", fg_color="#A6E3A1", text_color="#11111B", font=ctk.CTkFont(weight="bold"), command=self._on_click_retrain)
        btn_train.pack(side="right", padx=15, pady=10)

        # Training Metrics Cards
        cards_frame = ctk.CTkFrame(self.tab_training, fg_color="transparent")
        cards_frame.pack(fill="x", padx=10, pady=5)

        self.card_crossovers = self._create_card(cards_frame, "Day 1 Crossovers", "0", "#89B4FA")
        self.card_crossovers.pack(side="left", fill="x", expand=True, padx=5)

        self.card_accuracy = self._create_card(cards_frame, "Day 1 Model Accuracy", "-- %", "#A6E3A1")
        self.card_accuracy.pack(side="left", fill="x", expand=True, padx=5)

        self.card_precision = self._create_card(cards_frame, "Precision Score", "-- %", "#F9E2AF")
        self.card_precision.pack(side="left", fill="x", expand=True, padx=5)

        # Feature Importance Chart
        chart_box = ctk.CTkFrame(self.tab_training, fg_color="#11111B", corner_radius=6)
        chart_box.pack(fill="both", expand=True, padx=10, pady=10)

        lbl_feat = ctk.CTkLabel(chart_box, text="📊 Day 1 Feature Permutation Importance Scores (LTQ, Depth Imbalance, SMMA Spread)", font=ctk.CTkFont(size=11, weight="bold"), text_color="#89B4FA")
        lbl_feat.pack(anchor="w", padx=15, pady=10)

        self.feat_canvas = tk.Canvas(chart_box, bg="#11111B", highlightthickness=0)
        self.feat_canvas.pack(fill="both", expand=True, padx=15, pady=(0, 15))

    def _create_card(self, parent, title, value, color):
        card = ctk.CTkFrame(parent, fg_color="#11111B", corner_radius=6)
        t_lbl = ctk.CTkLabel(card, text=title, font=ctk.CTkFont(size=11), text_color="#A6ADC8")
        t_lbl.pack(padx=10, pady=(8, 2))
        v_lbl = ctk.CTkLabel(card, text=value, font=ctk.CTkFont(size=18, weight="bold"), text_color=color)
        v_lbl.pack(padx=10, pady=(0, 8))
        card.v_lbl = v_lbl
        return card

    def _build_papertrade_tab(self):
        # Stats summary row
        stats_frame = ctk.CTkFrame(self.tab_papertrade, fg_color="transparent")
        stats_frame.pack(fill="x", padx=10, pady=10)

        self.card_win_rate = self._create_card(stats_frame, "Successful Trades % (Win Rate)", "0.0%", "#A6E3A1")
        self.card_win_rate.pack(side="left", fill="x", expand=True, padx=4)

        self.card_loss_rate = self._create_card(stats_frame, "Unsuccessful Trades % (Loss Rate)", "0.0%", "#F38BA8")
        self.card_loss_rate.pack(side="left", fill="x", expand=True, padx=4)

        self.card_avoided_pct = self._create_card(stats_frame, "Avoided Trades % (Loss Prevented)", "0.0%", "#F9E2AF")
        self.card_avoided_pct.pack(side="left", fill="x", expand=True, padx=4)

        self.card_pnl = self._create_card(stats_frame, "Net Paper P&L (₹)", "₹0.00", "#89B4FA")
        self.card_pnl.pack(side="left", fill="x", expand=True, padx=4)

        # Paper Trades Table
        log_frame = ctk.CTkFrame(self.tab_papertrade, fg_color="#11111B", corner_radius=6)
        log_frame.pack(fill="both", expand=True, padx=10, pady=10)

        lbl_log = ctk.CTkLabel(log_frame, text="📜 Live Paper Trade Executions & Avoided Crossovers Log", font=ctk.CTkFont(size=11, weight="bold"), text_color="#CDD6F4")
        lbl_log.pack(anchor="w", padx=15, pady=8)

        cols = ("time", "symbol", "signal", "entry_p", "exit_p", "pnl", "status", "reason")
        self.trade_tree = ttk.Treeview(log_frame, columns=cols, show="headings", selectmode="browse")

        headers = {
            "time": "Time", "symbol": "Symbol", "signal": "Signal",
            "entry_p": "Entry (₹)", "exit_p": "Exit (₹)", "pnl": "P&L (₹)",
            "status": "Trade Status", "reason": "Reason for Trade / Avoidance"
        }
        for c, text in headers.items():
            self.trade_tree.heading(c, text=text)
            self.trade_tree.column(c, anchor="center", width=90)

        self.trade_tree.column("reason", width=420, anchor="w")
        self.trade_tree.column("status", width=140)

        sb = ttk.Scrollbar(log_frame, orient="vertical", command=self.trade_tree.yview)
        self.trade_tree.configure(yscrollcommand=sb.set)
        self.trade_tree.pack(side="left", fill="both", expand=True, padx=10, pady=(0, 10))
        sb.pack(side="right", fill="y", pady=(0, 10))

        # Seed initial Day 2 paper trades so statistics & traded stocks display immediately on startup
        self.paper_trader.seed_initial_paper_trades(self.ai_evaluator)
        for trade in self.paper_trader.closed_trades:
            self._add_trade_to_table(trade)
        for avoid in self.paper_trader.avoided_trades:
            self._add_trade_to_table({
                'entry_time': avoid['timestamp'],
                'symbol': avoid['symbol'],
                'signal_type': avoid['signal_type'],
                'entry_price': avoid['ltp'],
                'exit_price': '-',
                'pnl': 0.0,
                'status': 'TRADE AVOIDED',
                'reason': avoid['reason']
            })
        self._refresh_paper_trade_stats()

    def _build_statusbar(self):
        self.status_bar = ctk.CTkLabel(self, text="System Ready | 1-Min Timeframe Connected", anchor="w", font=ctk.CTkFont(size=11), text_color="#A6ADC8")
        self.status_bar.pack(fill="x", padx=15, pady=(0, 5))

    def _on_click_retrain(self):
        self.status_bar.configure(text="Retraining Day 1 ML Model on 1-min candles...")
        threading.Thread(target=self._auto_train_ml_model, daemon=True).start()

    def _update_training_ui(self, summary):
        self.card_crossovers.v_lbl.configure(text=str(summary.get('total_crossovers', 0)))
        self.card_accuracy.v_lbl.configure(text=f"{summary.get('accuracy', 0)}%")
        self.card_precision.v_lbl.configure(text=f"{summary.get('precision', 0)}%")
        self._draw_feature_importance_chart(summary.get('feature_importances', {}))
        self.status_bar.configure(text=f"Day 1 ML Model Trained Successfully | Accuracy: {summary.get('accuracy', 0)}%")

    def _draw_feature_importance_chart(self, importances):
        self.feat_canvas.delete("all")
        if not importances:
            return
        
        w = self.feat_canvas.winfo_width() or 800
        h = self.feat_canvas.winfo_height() or 220

        names = list(importances.keys())
        vals = list(importances.values())
        max_v = max(vals) if vals else 1.0

        bar_h = 24
        gap = 12
        top_y = 20

        for i, (name, val) in enumerate(importances.items()):
            y = top_y + i * (bar_h + gap)
            pct = val / max_v
            bar_w = int((w - 240) * pct)

            label_map = {
                'ltq_ratio': 'LTQ (Last Traded Qty) Ratio',
                'depth_imbalance': 'Order Book Depth Imbalance',
                'smma_spread': '20/120 SMMA Spread %',
                'smma_slope': '20 SMMA Slope Velocity',
                'vol_surge_ratio': 'Volume Surge Acceleration',
                'price_dev': 'Price Deviation'
            }
            lbl_text = label_map.get(name, name)

            self.feat_canvas.create_text(180, y + bar_h/2, text=lbl_text, fill="#CDD6F4", font=("Segoe UI", 9, "bold"), anchor="e")
            self.feat_canvas.create_rectangle(190, y, 190 + bar_w, y + bar_h, fill="#89B4FA", outline="")
            self.feat_canvas.create_text(200 + bar_w, y + bar_h/2, text=f"{val*100:.1f}%", fill="#A6E3A1", font=("Segoe UI", 9, "bold"), anchor="w")

    def on_tick_update(self, symbol, data, metrics):
        ltp = data['ltp']
        # Process live paper trader price update
        closed = self.paper_trader.update_live_price(symbol, ltp)
        if closed:
            self._add_trade_to_table(closed)

        self.latest_data[symbol] = {'data': data, 'metrics': metrics, 'ts': time.time()}

    def _periodic_ui_refresh(self):
        if getattr(self, "_pending_ml_summary", None) is not None:
            summary = self._pending_ml_summary
            self._pending_ml_summary = None
            try:
                self._update_training_ui(summary)
            except Exception as e:
                print("Update training UI error:", e)

        for symbol, entry in list(self.latest_data.items()):
            data = entry['data']
            metrics = entry['metrics']
            ltp = data['ltp']
            bid_qty = data['total_bid_qty']
            ask_qty = data['total_ask_qty']

            if not (LTP_MIN <= ltp <= LTP_MAX) or not (bid_qty >= BID_QTY_MIN and ask_qty >= ASK_QTY_MIN):
                if self.tree.exists(symbol):
                    self.tree.delete(symbol)
                continue

            smma_20 = metrics['smma_20']
            smma_120 = metrics['smma_120']
            prev_rel = self.crossover_states.get(symbol, "NEUTRAL")

            crossover_text = "NEUTRAL"
            if smma_20 > smma_120:
                crossover_text = "BULLISH (20 > 120)"
                current_rel = "ABOVE"
            elif smma_20 < smma_120:
                crossover_text = "BEARISH (20 < 120)"
                current_rel = "BELOW"
            else:
                current_rel = prev_rel

            # Evaluate AI Signal & execute Paper Trade on crossover trigger
            if prev_rel != "NEUTRAL" and current_rel != prev_rel:
                sig_type = "BUY" if current_rel == "ABOVE" else "SELL"
                eval_res = self.ai_evaluator.evaluate_signal(sig_type, symbol, data, metrics)
                self._display_ai_result(symbol, eval_res)
                
                # Paper trade execution & stats log
                res = self.paper_trader.process_signal(symbol, sig_type, ltp, eval_res)
                if res['action'] == 'OPENED':
                    pos = res['position']
                    self._add_trade_to_table({
                        'entry_time': pos['entry_time'], 'symbol': symbol, 'signal_type': sig_type,
                        'entry_price': ltp, 'exit_price': '-', 'pnl': 0.0,
                        'status': 'ACTIVE POSITION', 'reason': f"Model Win Prob {eval_res['probability']}% >= 60%"
                    })
                elif res['action'] == 'AVOIDED':
                    self._add_trade_to_table({
                        'entry_time': time.strftime('%H:%M:%S'), 'symbol': symbol, 'signal_type': sig_type,
                        'entry_price': ltp, 'exit_price': '-', 'pnl': 0.0,
                        'status': 'TRADE AVOIDED', 'reason': res['reason']
                    })

            self.crossover_states[symbol] = current_rel
            bid_price = data.get('best_bid_price', ltp)
            ask_price = data.get('best_ask_price', ltp)
            ltq_ratio = data.get('ltq_ratio', metrics['vol_5m']/10000.0)

            row_values = (
                symbol, f"₹{ltp:.2f}", f"₹{bid_price:.2f}", f"{bid_qty:,}", f"₹{ask_price:.2f}",
                f"{ask_qty:,}", f"{smma_20:.2f}", f"{smma_120:.2f}", f"{metrics['vol_5m']:,}",
                f"{ltq_ratio:.2f}x", crossover_text
            )

            if self.tree.exists(symbol):
                self.tree.item(symbol, values=row_values)
            else:
                self.tree.insert("", "end", iid=symbol, values=row_values)

        self._refresh_paper_trade_stats()
        self.after(500, self._periodic_ui_refresh)

    def _refresh_paper_trade_stats(self):
        stats = self.paper_trader.get_statistics()
        self.card_win_rate.v_lbl.configure(text=f"{stats['win_rate_pct']}%")
        self.card_loss_rate.v_lbl.configure(text=f"{stats['loss_rate_pct']}%")
        self.card_avoided_pct.v_lbl.configure(text=f"{stats['avoided_trades_pct']}%")
        pnl_color = "#A6E3A1" if stats['net_pnl'] >= 0 else "#F38BA8"
        self.card_pnl.v_lbl.configure(text=f"₹{stats['net_pnl']:,.2f}", text_color=pnl_color)

    def _add_trade_to_table(self, trade):
        vals = (
            trade.get('entry_time', trade.get('exit_time', '-')),
            trade['symbol'], trade['signal_type'],
            f"₹{trade['entry_price']:.2f}",
            f"₹{trade['exit_price']:.2f}" if isinstance(trade['exit_price'], (int, float)) else trade['exit_price'],
            f"₹{trade['pnl']:.2f}" if trade['pnl'] != 0 else "-",
            trade['status'], trade['reason']
        )
        self.trade_tree.insert("", 0, values=vals)

    def _on_row_select(self, event):
        selected = self.tree.selection()
        if not selected:
            return
        symbol = selected[0]
        if symbol in self.latest_data:
            entry = self.latest_data[symbol]
            metrics = entry['metrics']
            data = entry['data']
            smma_20 = metrics['smma_20']
            smma_120 = metrics['smma_120']
            sig_type = "BUY" if smma_20 >= smma_120 else "SELL"
            eval_res = self.ai_evaluator.evaluate_signal(sig_type, symbol, data, metrics)
            self._display_ai_result(symbol, eval_res)

    def _display_ai_result(self, symbol, eval_res):
        self.ai_output_box.configure(state="normal")
        self.ai_output_box.delete("1.0", "end")
        
        status_tag = "✅ APPROVED" if eval_res['is_approved'] else "⚠️ AVOID / REJECTED"
        text = f"[{time.strftime('%H:%M:%S')}] SYMBOL: {symbol} | SIGNAL: {eval_res['signal_type']} 20/120 SMMA CROSSOVER | STATUS: {status_tag}\n"
        text += f"DAY 1 ML MODEL WIN PROBABILITY: {eval_res['probability']}%\n"
        text += f"EXPLANATION / REASON: {eval_res['explanation']}\n"
        text += f"PERMUTATION METRICS: LTQ Ratio: {eval_res['features']['ltq_ratio']:.2f}x | Depth Imbalance: {eval_res['features']['depth_imbalance']:.2f} | SMMA Spread: {eval_res['features']['smma_spread']*100:.2f}%"

        self.ai_output_box.insert("1.0", text)
        self.ai_output_box.configure(state="disabled")
        self._draw_depth_chart(symbol, eval_res)

    def _draw_depth_chart(self, symbol, eval_res):
        self.canvas.delete("all")
        imbalance = eval_res['features']['depth_imbalance']
        prob = eval_res['probability']
        
        self.canvas.create_text(140, 12, text=f"Order Book: {symbol}", fill="#CDD6F4", font=("Segoe UI", 9, "bold"))
        bid_pct = max(0.1, min(0.9, (imbalance + 1.0) / 2.0))
        ask_pct = 1.0 - bid_pct

        bid_w = int(240 * bid_pct)
        self.canvas.create_rectangle(20, 26, 20 + bid_w, 42, fill="#A6E3A1", outline="")
        self.canvas.create_text(25, 34, text=f"Bids: {int(bid_pct*100)}%", fill="#11111B", font=("Segoe UI", 8, "bold"), anchor="w")

        self.canvas.create_rectangle(20 + bid_w, 26, 260, 42, fill="#F38BA8", outline="")
        self.canvas.create_text(255, 34, text=f"Asks: {int(ask_pct*100)}%", fill="#11111B", font=("Segoe UI", 8, "bold"), anchor="e")

        prob_color = "#A6E3A1" if prob >= 60 else "#F38BA8"
        self.canvas.create_text(140, 56, text=f"Day 1 ML Win Prob: {prob}%", fill=prob_color, font=("Segoe UI", 9, "bold"))
        self.canvas.create_rectangle(20, 68, 260, 78, fill="#313244", outline="")
        prob_w = int(240 * (prob / 100.0))
        self.canvas.create_rectangle(20, 68, 20 + prob_w, 78, fill=prob_color, outline="")

if __name__ == "__main__":
    app = StockScreenerApp()
    app.mainloop()

