# 🚀 Stock Market AI/ML Screener, Day 1 Model Training & Live Paper Trading System

Welcome! This repository contains the complete quantitative solution for **Stock Market AI/ML Screening, Day 1 Model Training & Live Paper Trading System**.

---

## 📌 Revised Features & Upgrades Implemented

1. **Real 1-Minute Market Data Feed**:
   - Timeframe: **1-Minute Candles**.
   - Indicators: **20 SMMA** (short-term) and **120 SMMA** (long-term).
   - Real market data fetched via `yfinance` / Angel API.

2. **Day 1 ML Training $\rightarrow$ Day 2 Testing Workflow**:
   - **Day 1 Training**: Fetches real 1-minute historical data for Day 1, identifies 20/120 SMMA crossovers, evaluates forward price action to label win (1) vs loss (0), and trains a **RandomForestClassifier**.
   - **Day 2 Inference**: On Day 2 / live stream, uses the trained model to predict win probability and identify which crossovers should be taken and which must be avoided to prevent losses.

3. **Feature Permutations (including LTQ)**:
   - Permutation features engineered into the model:
     - **LTQ Ratio (Last Traded Quantity)** volume ratio vs 20m average
     - **Order Book Depth Imbalance** (Bid Qty vs Ask Qty ratio)
     - **SMMA Spread & Slope Velocity**
     - **Volume Expansion** (1m vs 20m/60m rolling rate)
     - **Price Volatility / Deviation**

4. **Live Paper Trading Engine & Performance Analytics**:
   - Virtual paper trading (no real money invested).
   - Real-time statistics:
     - **Successful Trades % (Win Rate)**
     - **Unsuccessful Trades % (Loss Rate)**
     - **Avoided Trades Count & %**
     - **Net Paper P&L (₹)**

5. **Explicit Reasons for Avoided Trades**:
   - Detailed plain-language explainability log for every avoided crossover (e.g. *"Avoided: Insufficient LTQ volume expansion (1.05x < 1.1x required threshold)"*, *"Avoided: Heavy ask wall overhead"*).

---

## 🛠 How to Run & Test

### Option A: Running from Python
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Run the application:
   ```bash
   python main.py
   ```

### Option B: Building the Standalone `.exe`
Run the automated build script:
```bash
python build_exe.py
```

---

## 🎥 Revised Video Demonstration Script (for revised submission)

When recording your revised video, demonstrate these 4 sections:

1. **Introduction & 1-Min Dashboard (0:00 - 0:45)**:
   - Show `main.py` launching the 3-tab CustomTkinter dark interface.
   - Explain the 1-minute timeframe, 20 SMMA, 120 SMMA, and LTP filter (₹30–₹500).

2. **Day 1 ML Model Training & Feature Importance (0:45 - 1:45)**:
   - Switch to **"🤖 Day 1 ML Training & Features"** tab.
   - Show the Day 1 model training metrics (Accuracy %, Precision %) and the **Feature Importance Bar Chart** highlighting **LTQ Ratio**, **Depth Imbalance**, and **SMMA Spread**.

3. **Day 2 Live Paper Trading & Win/Loss Stats (1:45 - 2:30)**:
   - Switch to **"📊 Live Paper Trading & Win/Loss Stats"** tab.
   - Point out **Successful Trades % (Win Rate)**, **Unsuccessful Trades % (Loss Rate)**, and **Avoided Trades %**.

4. **Trade Avoidance Explanations (2:30 - 3:15)**:
   - Show the detailed trade log and explain how the model avoided bad crossovers to prevent loss (highlighting explicit avoidance reasons like LTQ threshold or order book imbalance).

